/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import database.tables.EditBookingsTable;
import database.tables.EditPetKeepersTable;
import database.tables.EditPetOwnersTable;
import database.tables.EditPetsTable;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mainClasses.Booking;
import mainClasses.Pet;
import mainClasses.PetKeeper;
import mainClasses.PetOwner;

/**
 *
 * @author nikvi
 */
public class BookKeeper extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet BookKeeper</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet BookKeeper at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            EditPetKeepersTable keeper_editor = new EditPetKeepersTable();
            ArrayList<PetKeeper> keepers = keeper_editor.getAllKeepers();;
            PetKeeper keeper = null;
            int keeper_id = 0;
            EditPetOwnersTable owner_editor = new EditPetOwnersTable();
            PetOwner owner = null;
            int owner_id = 0;
            EditPetsTable pet_editor = new EditPetsTable();
            Pet pet = null;
            int price = 0;
            EditBookingsTable booking_editor = new EditBookingsTable();
            String keeper_username = request.getParameter("username");
            //keeper username
            //booking date
            //owner
            //pet

            //Get Keeper and keeper_id
            for (PetKeeper kpr : keepers) {
                if (kpr.getUsername().equals(keeper_username)) {
                    keeper = kpr;
                }
            }
            if (keeper == null) {
                response.setStatus(404);
                return;
            }
            keeper_id = keeper_editor.getKeeperIdByUsername(keeper_username);

            //Get Owner and owner_id
            owner = owner_editor.databaseToPetOwners(request.getSession(false).getAttribute("username").toString(),
                    request.getSession(false).getAttribute("password").toString());
            if (owner == null) {
                response.setStatus(404);
                return;
            }
            owner_id = owner_editor.getOwnerIdByUsername(request.getSession(false).getAttribute("username").toString());
            if (owner_id == 0) {
                response.setStatus(404);
                return;
            }

            //Get pet
            pet = pet_editor.petOfOwner(Integer.toString(owner_id));
            if (pet == null) {
                response.setStatus(404);
                return;
            }

            //Get price
            if (pet.getType().equals("dog")) {
                price = keeper.getDogprice();
            } else {
                price = keeper.getCatprice();
            }
            if (price < 1) {
                response.setStatus(406);
                return;
            }

            //Check for other Bookings for Keeper and Owner
            ArrayList<Booking> bookings = booking_editor.databaseToBookings();
            for (Booking bkng : bookings) {
                if (((bkng.getKeeper_id() == keeper_id || bkng.getOwner_id() == owner_id)
                        && ("requested".equals(bkng.getStatus())
                        || "accepted".equals(bkng.getStatus())))) {
                    response.setStatus(406);
                    return;
                }
            }

            //Add booking
            booking_editor.createNewBooking(new Booking(owner_id, pet.getPet_id(), keeper_id,
                    request.getParameter("from"), request.getParameter("to"),
                    "requested", price
            ));
        } catch (SQLException ex) {
            Logger.getLogger(BookKeeper.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BookKeeper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected boolean checkDateOverlap(String fromDate1, String toDate1, String fromDate2, String toDate2) {
        LocalDate start1 = LocalDate.parse(fromDate1);
        LocalDate end1 = LocalDate.parse(toDate1);
        LocalDate start2 = LocalDate.parse(fromDate2);
        LocalDate end2 = LocalDate.parse(toDate2);

        return !(end1.isBefore(start2) || start1.isAfter(end2));
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
