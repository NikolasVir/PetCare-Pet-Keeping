package servlets;

import database.tables.EditPetKeepersTable;
import database.tables.EditPetOwnersTable;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mainClasses.PetKeeper;
import mainClasses.PetOwner;

/**
 *
 * @author nikvi
 */
public class GetUserInfo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession ses = request.getSession(false);
        if (ses == null) {
            System.out.println("Null");
            return;
        }
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet GetUserInfo</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet GetUserInfo at " + ses.getAttribute("username") + " "
                    + ses.getAttribute("password") + "</h1>"
            );
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            EditPetKeepersTable keeperEditor = new EditPetKeepersTable();
            EditPetOwnersTable ownerEditor = new EditPetOwnersTable();

            HttpSession ses = request.getSession(false);
            if (ses == null) {
                response.setStatus(403);
                return;
            }

            String username = ses.getAttribute("username").toString();
            String password = ses.getAttribute("password").toString();
            System.out.println("HERE");
            System.out.println(username);
            System.out.println(password);
            String keeper = keeperEditor.databasePetKeeperToJSON(username, password);
            String owner = ownerEditor.databasePetOwnerToJSON(username, password);
            System.out.println(owner);
            System.out.println(keeper);
            PrintWriter out = response.getWriter();

//            if (keeper == null && owner == null) {
//                System.out.println("true");
//                response.setStatus(406);
//                return;
//            }
            if (keeper == null) { //User is owner
                out.print(owner);
            } else { // User is keeper
                out.print(keeper);
            }
            out.flush();

            response.setStatus(200);
            return;

        } catch (SQLException ex) {
            Logger.getLogger(GetUserInfo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GetUserInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
