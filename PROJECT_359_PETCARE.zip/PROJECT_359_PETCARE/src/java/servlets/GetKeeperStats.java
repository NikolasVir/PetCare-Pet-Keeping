/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import com.google.gson.JsonObject;
import database.tables.EditBookingsTable;
import database.tables.EditPetKeepersTable;
import database.tables.EditReviewsTable;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mainClasses.Booking;
import mainClasses.PetKeeper;
import mainClasses.Review;

/**
 *
 * @author nikvi
 */
public class GetKeeperStats extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet GetKeeperStats</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet GetKeeperStats at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("application/json");
            String username = request.getSession(false).getAttribute("username").toString();
            //All only for finished
            int numberOfBookings = 0;
            int totalKeepingDays = 0;
            int totalReviewScore = 0;
            int numberOfReviews = 0;
            EditBookingsTable bookings_editor = new EditBookingsTable();
            EditPetKeepersTable keeper_editor = new EditPetKeepersTable();
            EditReviewsTable review_editor = new EditReviewsTable();
            int keeper_id = keeper_editor.getKeeperIdByUsername(username);
            ArrayList<Booking> bookings = bookings_editor.databaseToBookings();
            ArrayList<Review> reviews = review_editor.databaseTokeeperReviews(Integer.toString(keeper_id));

            for (Booking booking : bookings) {
                if (keeper_id == booking.getKeeper_id() && booking.getStatus().equals("finished")) {
                    numberOfBookings++;
                    totalKeepingDays += calculateTemporalDistance(booking.getFromDate(), booking.getToDate());
                }
            }
            for (Review review : reviews) {
                numberOfReviews++;
                totalReviewScore += Integer.parseInt(review.getReviewScore());
            }

            JsonObject jsonObject = new JsonObject();

            jsonObject.addProperty("numberOfBookings", numberOfBookings);
            jsonObject.addProperty("totalKeepingDays", totalKeepingDays);
            jsonObject.addProperty("totalReviewScore", totalReviewScore);
            jsonObject.addProperty("numberOfReviews", numberOfReviews);

            String json = jsonObject.toString();

            response.getWriter().write(json);

        } catch (SQLException ex) {
            Logger.getLogger(GetKeeperStats.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GetKeeperStats.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    public static long calculateTemporalDistance(String dateString1, String dateString2) {
        // Define the date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Parse the date strings to LocalDate objects
        LocalDate date1 = LocalDate.parse(dateString1, formatter);
        LocalDate date2 = LocalDate.parse(dateString2, formatter);

        // Calculate the temporal distance in days
        long daysBetween = ChronoUnit.DAYS.between(date1, date2);

        return daysBetween;
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
