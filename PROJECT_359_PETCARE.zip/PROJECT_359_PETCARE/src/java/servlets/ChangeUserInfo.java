package servlets;

import database.tables.EditPetKeepersTable;
import database.tables.EditPetOwnersTable;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mainClasses.PetKeeper;
import mainClasses.PetOwner;

/**
 *
 * @author nikvi
 */
public class ChangeUserInfo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ChangeUserInfo</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ChangeUserInfo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //CHANGING USER FROM PETKEEPER/PETOWNER TO PETOWNER/PETKEEPER NOT SUPPORTED
        response.setContentType("text/html;charset=UTF-8");
        String password = request.getParameter("password");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String birthdate = request.getParameter("birthdate");
        String gender = request.getParameter("gender");
        String type = request.getParameter("type");
        String property = request.getParameter("keeper_property");
        String keeper_type = request.getParameter("keeper_type");
        String catprice_s = request.getParameter("catprice");
        String dogprice_s = request.getParameter("dogprice");
        String propertyDescription = request.getParameter("propertyDescription");
        String country = request.getParameter("country");
        String city = request.getParameter("city");
        String address = request.getParameter("address");
        String personalpage = request.getParameter("personalpage");
        String job = request.getParameter("job");
        String telephone = request.getParameter("telephone");
        String lat_s = request.getParameter("lat");
        String lon_s = request.getParameter("lon");

        int dogprice = -1;
        int catprice = -1;
        if (keeper_type != null) {

            if (keeper_type.equals("dogkeeper")) {
                if (dogprice_s.equals("")) {
                    response.setStatus(406);
                    return;
                } else {
                    dogprice = Integer.parseInt(dogprice_s);
                }
            }

            if (keeper_type.equals("catkeeper")) {
                if (catprice_s.equals("")) {
                    response.setStatus(406);
                    return;
                } else {
                    catprice = Integer.parseInt(catprice_s);
                }
            }
        }
        Double lat;
        Double lon;
        if (lat_s.equals("undefined")) {
            response.setStatus(406);
            return;
        } else {
            lat = Double.parseDouble(lat_s);
            lon = Double.parseDouble(lon_s);
        }
        EditPetKeepersTable keeperEditor = new EditPetKeepersTable();
        EditPetOwnersTable ownerEditor = new EditPetOwnersTable();

        HttpSession ses = request.getSession(false);
        String username = ses.getAttribute("username").toString();

        if (type.equals("keeper")) {
            try {
                PetKeeper keeper = createPetKeeper(username, "irrelevant", password, firstname, lastname,
                        birthdate, gender, property, keeper_type, catprice, dogprice, propertyDescription,
                        country, city, address, personalpage, job, telephone, lat, lon);
                System.out.println(keeper.getFirstname());
                keeperEditor.changePetKeeper(keeper);
                request.getSession(false).setAttribute("password", password);
            } catch (SQLException ex) {
                Logger.getLogger(ChangeUserInfo.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ChangeUserInfo.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            try {
                PetOwner owner = createPetOwner(username, "irrelevant", password, firstname, lastname,
                        birthdate, gender, country, city, address, personalpage, job, telephone, lat, lon);
                ownerEditor.changePetOwner(owner);
                request.getSession(false).setAttribute("password", password);
            } catch (SQLException ex) {
                Logger.getLogger(ChangeUserInfo.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ChangeUserInfo.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?");
    }

    private PetOwner createPetOwner(
            String username,
            String email,
            String password,
            String firstname,
            String lastname,
            String birthdate,
            String gender,
            String country,
            String city,
            String address,
            String personalpage,
            String job,
            String telephone,
            Double lat,
            Double lon) {

        PetOwner owner = new PetOwner();
        owner.setUsername(username);
        owner.setEmail(email);
        owner.setPassword(password);
        owner.setFirstname(firstname);
        owner.setLastname(lastname);
        owner.setBirthdate(birthdate);
        owner.setGender(gender);
        owner.setCountry(country);
        owner.setCity(city);
        owner.setAddress(address);
        owner.setPersonalpage(personalpage);
        owner.setJob(job);
        owner.setTelephone(telephone);
        owner.setLat(lat);
        owner.setLon(lon);

        return owner;
    }

    private PetKeeper createPetKeeper(
            String username,
            String email,
            String password,
            String firstname,
            String lastname,
            String birthdate,
            String gender,
            String property,
            String keeper_type,
            int catprice,
            int dogprice,
            String propertyDescription,
            String country,
            String city,
            String address,
            String personalpage,
            String job,
            String telephone,
            Double lat,
            Double lon) {

        PetKeeper keeper = new PetKeeper();
        keeper.setUsername(username);
        keeper.setEmail(email);
        keeper.setPassword(password);
        keeper.setFirstname(firstname);
        keeper.setLastname(lastname);
        keeper.setBirthdate(birthdate);
        keeper.setGender(gender);
        keeper.setProperty(property);

        boolean isDogkeeper = false;
        if (keeper_type.equals("Dogkeeper")) {
            isDogkeeper = true;
        }
        keeper.setDogkeeper(Boolean.toString(isDogkeeper));

        boolean isCatkeeper = false;
        if (keeper_type.equals("Catkeeper")) {
            isCatkeeper = true;
        }
        keeper.setCatkeeper(Boolean.toString(isCatkeeper));

        keeper.setDogprice(dogprice);
        keeper.setCatprice(catprice);
        keeper.setPropertydescription(propertyDescription);
        keeper.setCountry(country);
        keeper.setCity(city);
        keeper.setAddress(address);
        keeper.setPersonalpage(personalpage);
        keeper.setJob(job);
        keeper.setTelephone(telephone);
        keeper.setLat(lat);
        keeper.setLon(lon);

        return keeper;
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
