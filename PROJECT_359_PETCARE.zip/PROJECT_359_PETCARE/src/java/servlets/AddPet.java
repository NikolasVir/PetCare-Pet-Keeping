/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import com.google.gson.Gson;
import database.tables.EditPetOwnersTable;
import database.tables.EditPetsTable;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mainClasses.Pet;
import mainClasses.PetOwner;

/**
 *
 * @author nikvi
 */
public class AddPet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddPet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddPet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Does not throw error when crashing
        Gson gson = new Gson();
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        String json = sb.toString();

        Pet pet = gson.fromJson(json, Pet.class);

        if (Integer.toString(pet.getPet_id()).length() < 10) {
            response.setStatus(406);
            return;
        }

        EditPetsTable petEditor = new EditPetsTable();

        EditPetOwnersTable ownerEditor = new EditPetOwnersTable();

        PetOwner owner = null;
        try {
            owner = ownerEditor.databaseToPetOwners(pet.getOwner_id());
        } catch (SQLException ex) {
            Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (owner == null) {
            response.setStatus(406);
            return;
        }

        if (pet.getBirthyear() <= 2000 || pet.getWeight() <= 0) {
            response.setStatus(406);
            return;
        }

        if (!startsWithHttp(pet.getPhoto())) {
            response.setStatus(406);
            return;
        }

        ArrayList<Pet> pets = null;
        try {
            pets = petEditor.databaseToPets();
        } catch (SQLException ex) {
            Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
        }

        for (Pet pet_temp : pets) {
            if (pet_temp.getPet_id() == pet.getPet_id()) {
                response.setStatus(406);
                return;
            }
        }

        try {
            try {
                if (petEditor.petOfOwner(Integer.toString(pet.getOwner_id())) != null) {
                    petEditor.addPetFromJSON(json);
                } else {
                    response.setStatus(406);
                }
            } catch (SQLException ex) {
                Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddPet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean startsWithHttp(String photo) {
        boolean flag = true;
        if (photo.charAt(0) != 'h'
                || photo.charAt(1) != 't'
                || photo.charAt(2) != 't'
                || photo.charAt(3) != 'p') {
            flag = false;
        }
        return flag;
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
