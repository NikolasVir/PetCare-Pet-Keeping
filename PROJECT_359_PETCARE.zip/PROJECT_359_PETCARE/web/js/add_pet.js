function addPet() {
    let form = document.getElementById('form');
    let formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => (data[key] = value));
    var jsonData = JSON.stringify(data);

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": pet added successfuly");
            } else if (xhr.status === 406) {
                alert(xhr.status + ": forbidden action(only one pet per owner or invalid arguments)");
            } else if (xhr.status !== 200) {
                alert(xhr.status + ": unknown error");
            }
        }
    };
    xhr.open('POST', 'AddPet');
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.send(jsonData);
}