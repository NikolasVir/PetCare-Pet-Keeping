function finishBooking() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": status changed successfuly");
                getBookings();
            } else if (xhr.status === 406) {
                alert(xhr.status + ": invalid arguments");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    var data = $("#finish_form").serialize();
    xhr.open('POST', 'FinishBooking');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function addReview() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": review added successfuly");
            } else if (xhr.status === 406) {
                alert(xhr.status + ": booking is not finished or wrong id");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    var data = $("#review_form").serialize();
    xhr.open('POST', 'AddReview');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function getBookings() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = makeBookingTable(JSON.parse(xhr.response));
            } else if (xhr.status === 403) {
                document.getElementById("response_container").innerHTML = "Invalid Query";
            } else {
                document.getElementById("response_container").innerHTML = "No past bookings";
            }
        }
    };

    xhr.open("GET", "GetPastBookings");
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();
}

function makeBookingTable(bookings) {
    var table = '<table style="font-size: 40px; border: 1px solid black; border-collapse: collapse; table-layout: fixed; width: 100%;">';

    var headers = ['borrowing_id', 'fromDate', 'toDate', 'status', 'price'];
    table += '<thead><tr>';

    headers.forEach(function (header) {
        // Convert camelCase to words for header display
        var displayHeader = header.replace(/([A-Z])/g, ' $1').replace(/^./, function (str) {
            return str.toUpperCase();
        });
        table += '<th style="padding: 10px; font-size: 40px;">' + displayHeader + '</th>';
    });
    table += '</tr></thead>';

    table += '<tbody>';
    bookings.forEach(function (booking) {
        table += '<tr>';
        headers.forEach(function (header) {
            var cellContent = booking[header];
            table += '<td style="padding: 10px; font-size: 40px;">' + cellContent + '</td>';
        });
        table += '</tr>';
    });
    table += '</tbody></table>';

    return table;
}

document.addEventListener("DOMContentLoaded", function () {
    getBookings();
});