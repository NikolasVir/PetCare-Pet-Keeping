document.addEventListener("DOMContentLoaded", map_setup());

//Orismos Thesis
function setPosition(lat, lon) {
    var fromProjection = new OpenLayers.Projection("EPSG:4326");   // Transform from WGS 1984
    var toProjection = new OpenLayers.Projection("EPSG:900913"); // to Spherical Mercator Projection
    var position = new OpenLayers.LonLat(lon, lat).transform(fromProjection, toProjection);
    return position;
}

//Orismos Handler
function handler(position, message) {
    var popup = new OpenLayers.Popup.FramedCloud("Popup",
        position, null,
        message, null,
        true // <-- true if we want a close (X) button, false otherwise
    );
    map.addPopup(popup);
}

function map_setup() {
    //Orismos marker
    map = new OpenLayers.Map("map");
    var mapnik = new OpenLayers.Layer.OSM();
    map.addLayer(mapnik);

    //Orismos zoom kai default position
    var position = setPosition(35.3053121, 25.0722869);
    const zoom = 10;
    map.setCenter(position, zoom);
}

var last_markers;
var marker_exists = false;

function add_marker() {
    var markers = new OpenLayers.Layer.Markers("Markers");
    map.addLayer(markers);
    var position = setPosition(lat, lon);
    var mar = new OpenLayers.Marker(position);
    markers.addMarker(mar);
    mar.events.register('mousedown', mar, function (evt) {
        handler(position, 'Your Address');
    }
    );
    map.setCenter(position, 10);
    last_markers = markers;
}

function remove_marker() {
    if (marker_exists) { // The first time this triggers is when a markers has not yet been placed
        map.removeLayer(last_markers);
    } else {
        marker_exists = true;
    }
}