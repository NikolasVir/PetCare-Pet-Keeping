window.onload = function () {
    document.getElementById("back_button").onclick = function () {
        window.location.replace("index.html");
    };
    getKeeperInfo();
};

function getKeeperInfo() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById('keeper_info_container').innerHTML = makeKeeperTable(JSON.parse(xhr.response));
            } else {
                document.getElementById("keeper_info_container").innerHTML = "Could not retrieve keepers";
            }
        }
    };
    xhr.open('GET', 'GetKeepers');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function makeKeeperTable(petKeepers) {
    var table = '<table style="font-size: 25px; border: 1px solid black; border-collapse: collapse;">';

    var headers = ['Username', 'Email', 'Password', 'First Name', 'Last Name', 'Birthdate', 'Gender', 'Job', 'Country', 'City', 'Address', 'Latitude', 'Longitude', 'Telephone', 'Personal Page', 'Property', 'Property Description', 'Cat Keeper', 'Dog Keeper', 'Cat Price', 'Dog Price'];
    table += '<thead><tr>';
    headers.forEach(function (header) {
        table += '<th>' + header + '</th>';
    });
    table += '</tr></thead>';

    table += '<tbody>';
    petKeepers.forEach(function (petKeeper) {
        table += '<tr>';
        headers.forEach(function (header) {
            table += '<td>' + petKeeper[header.toLowerCase().replace(/ /g, '')] + '</td>'; // Access the property of the object using the header
        });
        table += '</tr>';
    });
    table += '</tbody></table>';

    return table;
}
