function adminLogIn() {
    let form = document.getElementById("form");
    let username = form.elements["username"].value;
    let password = form.elements["password"].value;

    console.log(username);
    console.log(password);
    if (username === "admin" && password === "admin12*") {
        window.location.replace("admin_home.html");
    }
}


