document.addEventListener("DOMContentLoaded", function () {
    const type = document.getElementById("type");
    const keeper_type = document.getElementById("keeper_type");
    const keeper_property = document.getElementById("keeper_property");
    const address_feedback_cointainer = document.getElementById("address_feedback_cointainer");
    const address_feedback_text = document.getElementById("address_feedback_text");
    type.addEventListener('change', () => create_form(type, keeper_property, keeper_type));
    keeper_type.addEventListener('change', () => type_actions(keeper_type));
    keeper_property.addEventListener('change', () => property_form(keeper_property, keeper_type));
});

function property_form(keeper_property, keeper_type) {
    if (keeper_property.value == "outdoors") {
        keeper_type.removeChild(keeper_type.querySelector("option[value='catkeeper']"));
    } else if (keeper_type.options.length == 2) {
        let cat_option = document.createElement("option");
        cat_option.value = "catkeeper";
        cat_option.text = "Cats";
        keeper_type.appendChild(cat_option);
    }
}

function type_actions(keeper_type) {
    let catprice_form_container = document.getElementById("catprice_form_container");
    let dogprice_form_container = document.getElementById("dogprice_form_container");

    let catprice = document.getElementById("catprice");
    let dogprice = document.getElementById("dogprice");

    if (keeper_type.value == "catkeeper") {
        catprice_form_container.style.display = "block";
        dogprice_form_container.style.display = "none";
        catprice.required = true;
    }
    if (keeper_type.value == "dogkeeper") {
        catprice_form_container.style.display = "none";
        dogprice_form_container.style.display = "block";
        dogprice.required = true;
    }
}

function create_form(type, keeper_property, keeper_type) {
    if (type.value == "keeper") {
        keeper_form.style.display = "block";
        keeper_property.required = true;
        keeper_type.required = true;
        address_feedback_cointainer.style.margin = "1022px 0px 0px 1330px";
        address_feedback_text.style.margin = "1037px 0px 0px 1355px";
    } else {
        keeper_form.style.display = "none";
        keeper_property.required = false;
        keeper_type.required = false;
        address_feedback_cointainer.style.margin = "798px 0px 0px 1330px";
        address_feedback_text.style.margin = "813px 0px 0px 1355px";
    }
}