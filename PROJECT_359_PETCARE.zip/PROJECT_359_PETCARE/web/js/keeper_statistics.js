document.addEventListener("DOMContentLoaded", function () {
    getKeeperStats();
});


function getKeeperStats() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var json = JSON.parse(xhr.response);
                document.getElementById("response_container").innerHTML =
                        "Number of Bookings: " + json.numberOfBookings + "<br>" +
                        "Total Keeping Days: " + json.totalKeepingDays + "<br>" +
                        "Total Review Score: " + json.totalReviewScore + "<br>" +
                        "Number of Reviews: " + json.numberOfReviews + "<br>";
            } else {
                document.getElementById("response_container").innerHTML = "Unknown Error";
            }
        }
    };

    xhr.open("GET", "GetKeeperStats");
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();

}