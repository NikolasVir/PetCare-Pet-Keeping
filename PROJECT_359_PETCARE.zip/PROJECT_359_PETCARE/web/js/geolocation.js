var can_submit = false;
var lat;
var lon;

document.addEventListener('DOMContentLoaded', function () {
    const address_field = document.getElementById("address");
    const city_field = document.getElementById("city");
    address_field.onblur = function () {
        get_full_location();
    };
    city_field.onblur = function () {
        get_full_location();
    };
});

function get_full_location() {
    let country = document.getElementById("country").value;
    let city = document.getElementById("city").value;
    let address = document.getElementById("address").value;

    const data = null;

    const xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === this.DONE) {
            let map_parts = document.getElementsByClassName("map_parts");
            let address_feedback = document.getElementsByClassName("address_feedback_class");
            let response = JSON.parse(this.responseText);
            console.log(response);
            if (response[0] == undefined) {
                address_feedback[0].style.visibility = "visible";
                address_feedback[1].style.visibility = "visible";
                document.getElementById("address_feedback_text").innerHTML = "Incorrect address!";
                can_submit = false;

                map_parts[0].style.display = "none";
                map_parts[1].style.display = "none";
            } else {
                if (!(/Heraklion/.test(response[0].display_name) && /Greece/.test(response[0].display_name) && /Crete/.test(response[0].display_name))) {
                    address_feedback[0].style.visibility = "visible";
                    address_feedback[1].style.visibility = "visible";
                    document.getElementById("address_feedback_text").innerHTML = "Available in Heraklion, Crete, Greece!";
                    can_submit = false;

                    // Remove these and the comments below for automatic marker placement
                    //remove_marker();
                    map_parts[0].style.display = "none";
                    map_parts[1].style.display = "none";
                } else {
                    address_feedback[0].style.visibility = "hidden";
                    address_feedback[1].style.visibility = "hidden";
                    can_submit = true;

                    map_parts[0].style.display = "block";
                    map_parts[1].style.display = "block";
                    lat = response[0].lat;
                    lon = response[0].lon;
                    //remove_marker();
                    //add_marker();
                }
            }
        }
    });

    let addr = country + ' ' + city + ' ' + address;
    xhr.open("GET", "https://forward-reverse-geocoding.p.rapidapi.com/v1/search?q=" + addr + "&accept-language=en&polygon_threshold=0.0");
    xhr.setRequestHeader("x-rapidapi-host", "forward-reverse-geocoding.p.rapidapi.com");
    xhr.setRequestHeader("x-rapidapi-key", "74cc0aa785msh9c70ea863e3cae2p1a67b3jsna4afbf9a98b9");
    xhr.send(data)

}

function stop_animation_address() {
    let address_feedback_class = document.getElementsByClassName("address_feedback_class");
    address_feedback_class[0].style.animation = "fade 2s linear";
    address_feedback_class[1].style.animation = "fade 2s linear";
}

function alert_address() {
    document.getElementById("country").scrollIntoView();
    let address_feedback_style = document.getElementsByClassName("address_feedback_class");
    address_feedback_style[0].style.animation = "fade 2s infinite";
    address_feedback_style[1].style.animation = "fade 2s infinite";
    setTimeout(stop_animation_address, 3000);
}