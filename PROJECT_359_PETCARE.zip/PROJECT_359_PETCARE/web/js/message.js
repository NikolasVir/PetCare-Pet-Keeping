function isLoggedIn() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user already logged in");
            window.location.href = "/PROJECT_359/" + xhr.response + "_home.html";
        } else if (xhr.status === 403) {
            alert(xhr.status + ": user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('GET', 'GetUserSession');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function sendMessage() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                //alert(xhr.status + ": message sent successfuly");
                getMessages();
            } else if (xhr.status === 406) {
                alert(xhr.status + ": invalid arguments");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    var data = $("#chat_form").serialize();
    xhr.open('POST', 'SendMessage');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function getMessages() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = formatMessages(JSON.parse(xhr.response));
            } else if (xhr.status === 403) {
                document.getElementById("response_container").innerHTML = "Invalid Query";
            } else {
                document.getElementById("response_container").innerHTML = "No past messages";
            }
        }
    };

    xhr.open("GET", "GetMessages");
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.send();
}

function formatMessages(jsonData) {
    let formattedString = '';
    jsonData.forEach(item => {
        formattedString += item.sender + ':\n' + item.message + '<br>\n';
    });
    return formattedString;
}


document.addEventListener("DOMContentLoaded", function () {
    getMessages();
    setInterval(getMessages, 4000);
});