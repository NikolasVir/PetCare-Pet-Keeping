function logOut() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": logged out");
            window.location.href = "/PROJECT_359";
        } else if (xhr.status === 403) {
            alert(xhr.status + "user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('POST', 'LogOutUser');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}