function handleForm() {
    var accepted = document.getElementById("option1").checked;
    if (accepted) {
        accept();
    } else {
        reject();
    }
}

function accept() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": accepted booking successfuly");
                getBookings();
            } else if (xhr.status === 406) {
                alert(xhr.status + ": wrong id or can't accept booking");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    var data = $("#manage_form").serialize();
    xhr.open('POST', 'AcceptBooking');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function reject() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": rejected booking successfuly");
                getBookings();
            } else if (xhr.status === 406) {
                alert(xhr.status + ": invalid arguments");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    var data = $("#manage_form").serialize();
    xhr.open('POST', 'RejectBooking');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function getBookings() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = "";
                document.getElementById("response_container").appendChild(makeTable(JSON.parse(xhr.response)));
            } else if (xhr.status === 403) {
                document.getElementById("response_container").innerHTML = "Invalid Query";
            } else {
                document.getElementById("response_container").innerHTML = "No past bookings";
            }
        }
    };

    xhr.open("GET", "GetKeeperBookings");
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();
}

function makeTable(keeperBookingsResponse) {
    var table = document.createElement('table');
    table.style.fontSize = '30px'; // Set font size
    table.style.borderCollapse = 'collapse'; // Remove border

    // Create header row
    var headerRow = table.insertRow(0);
    var bookingHeaders = Object.keys(keeperBookingsResponse.bookings[0]);
    var petHeaders = Object.keys(keeperBookingsResponse.pets[0]);

    // Exclude unwanted fields (owner_id, keeper_id, pet_id)
    var excludedFields = ['owner_id', 'keeper_id', 'pet_id'];
    bookingHeaders = bookingHeaders.filter(header => !excludedFields.includes(header));
    petHeaders = petHeaders.filter(header => !excludedFields.includes(header));

    // Add booking headers
    for (var i = 0; i < bookingHeaders.length; i++) {
        var headerCell = headerRow.insertCell(i);
        headerCell.innerHTML = '<b>' + bookingHeaders[i] + '</b>';
    }

    // Add pet headers
    for (var i = 0; i < petHeaders.length; i++) {
        var headerCell = headerRow.insertCell(bookingHeaders.length + i);
        headerCell.innerHTML = '<b>' + petHeaders[i] + '</b>';
    }

    // Add data rows
    for (var i = 0; i < keeperBookingsResponse.bookings.length; i++) {
        var booking = keeperBookingsResponse.bookings[i];
        var pet = keeperBookingsResponse.pets[i];

        var row = table.insertRow(i + 1);

        // Add booking data
        for (var j = 0; j < bookingHeaders.length; j++) {
            var cell = row.insertCell(j);
            cell.innerHTML = booking[bookingHeaders[j]];
        }

        // Add pet data
        for (var j = 0; j < petHeaders.length; j++) {
            var cell = row.insertCell(bookingHeaders.length + j);
            cell.innerHTML = pet[petHeaders[j]];
        }
    }

    return table;
}

document.addEventListener("DOMContentLoaded", function () {
    getBookings();
});