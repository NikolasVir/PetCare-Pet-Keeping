function registerUser() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user added");
            window.location.href = "/PROJECT_359/index.html";
        } else if (xhr.status === 403) {
            alert(xhr.status + ": user already exists");
        } else if (xhr.status === 406) {
            alert(xhr.status + ": incorrect address or null pricing");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };

    var data = $('#form').serialize();
    data += "&lat=" + lat + "&lon=" + lon;
    console.log(data);
    xhr.open('POST', 'AddUser');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(data);
}
