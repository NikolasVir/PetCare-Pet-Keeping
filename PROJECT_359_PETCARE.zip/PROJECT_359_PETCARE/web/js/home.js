document.addEventListener("DOMContentLoaded", function () {
    getInfo();
});

function isLoggedIn() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user already logged in");
            window.location.href = "/PROJECT_359/" + xhr.response + "_home.html";
        } else if (xhr.status === 403) {
            alert(xhr.status + ": user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('GET', 'GetUserSession');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function logOut() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": logged out");
            window.location.href = "/PROJECT_359";
        } else if (xhr.status === 403) {
            alert(xhr.status + "user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('POST', 'LogOutUser');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function createTableFromJSON(data) {
    var html = "<table><tr><th>Category</th><th>Value</th></tr>";
    for (const x in data) {
        var category = x;
        var value = data[x];
        html += "<tr><td>" + category + "</td><td>" + value + "</td></tr>";
    }
    html += "</table>";
    return html;
}

function setDefaults(data) {
    const form = document.getElementById("form");
    form.elements["firstname"].value = data.firstname;
    form.elements["lastname"].value = data.lastname;
    form.elements["birthdate"].value = data.birthdate;
    var gender = document.querySelectorAll('input[name="gender"]');
    if (data.gender === "Woman") {
        gender[0].checked = true;
    } else if (data.gender === "Man") {
        gender[1].checked = true;
    } else {
        gender[2].checked = true;
    }

    if (data.catprice === undefined && data.dogprice === undefined) {
        form.elements["type"].value = "owner";
    } else {
        form.elements["type"].value = "keeper";
    }

    if (data.property === "Indoor") {
        form.elements["keeper_property"].value = "indoors";
    } else if (data.property === "Outdoor") {
        form.elements["keeper_property"].value = "outdoors";
    } else {
        form.elements["keeper_property"].value = "both";
    }
    if (form.elements["type"].value === "keeper") {
        if (data.dogkeeper !== -1) {
            form.elements["keeper_type"].value = "dogkeeper";
            form.elements["dogprice"].value = data.dogprice;
        }
        if (data.catkeeper !== -1) {
            form.elements["keeper_type"].value = "catkeeper";
            form.elements["catprice"].value = data.catprice;
        }

        form.elements["propertyDescription"].value = data.propertydescription;

        create_form(form.elements["type"], form.elements["keeper_property"], form.elements["keeper_type"]);
        type_actions(form.elements["keeper_type"]);
        property_form(form.elements["keeper_property"], form.elements["keeper_type"]);
    }
    //    form.elements["country"]. = data.country;
    // To autofill the country I would have to translate country codes to full names.

    form.elements["city"].value = data.city;
    form.elements["address"].value = data.address;
    form.elements["personalpage"].value = data.personalpage;
    form.elements["job"].value = data.job;
    form.elements["telephone"].value = data.telephone;

    lat = data.lat;
    lon = data.lon;

}

function changeInfo() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user changed");
            getInfo();
        } else if (xhr.status === 406) {
            alert(xhr.status + ": incorrect address or null pricing");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    var data = $('#form').serialize();
    data += "&lat=" + lat + "&lon=" + lon;
    xhr.open('POST', 'ChangeUserInfo');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(data);
}

function getInfo() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user logged in");
            var json = JSON.parse(xhr.responseText);
            var table_container = document.getElementById("info");
            table_container.innerHTML = createTableFromJSON(json);
            console.log(json);
            setDefaults(json);
        } else if (xhr.status === 403) {
            alert(xhr.status + ": user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('GET', 'GetUserInfo');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}


