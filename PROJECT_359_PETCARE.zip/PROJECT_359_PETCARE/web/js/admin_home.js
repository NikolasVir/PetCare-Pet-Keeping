document.addEventListener("DOMContentLoaded", function () {
    google.charts.load('current', {'packages': ['corechart']});
    google.charts.setOnLoadCallback(getData);
});

function deleteUser() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": user deleted");
            } else if (xhr.status === 404) {
                alert(xhr.status + ": user does not exist");
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };
    var data = $("#deletion_form").serialize();
    var url = "DeleteUser?" + data;
    xhr.open("DELETE", url);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function getData() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": data received");
                var responseData = JSON.parse(xhr.responseText);
                drawAllCharts(responseData.cats, responseData.dogs, (responseData.total_revenue * 0.85), (responseData.total_revenue * 0.15), responseData.keeper_ammount, responseData.owner_ammount);
            } else {
                alert(xhr.status + ": unknown error");
            }
        }
    };

    xhr.open('Get', 'GetAdminInfo');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}

function drawAllCharts(cats, dogs, keepers_rev, pet_care, keepers, owners) {
    drawChart1(cats, dogs);
    drawChart2(keepers_rev, pet_care);
    drawChart3(keepers, owners);
}

function drawChart1(cats, dogs) {
    var data = google.visualization.arrayToDataTable([
        ['Animal', 'Quantity'],
        ['Cats', cats],
        ['Dogs', dogs]
    ]);

    var options = {
        title: 'Animal Share',
        backgroundColor: '#F3F3F3',
        slices: {
            0: {color: '70566D'},
            1: {color: 'D6D6F4'}
        },
        titleTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 30,
            bold: false
        },
        pieSliceTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 26,
            bold: false
        },
        legend: {
            textStyle: {
                color: '0C0F0A',
                fontName: 'jomhuria',
                fontSize: 28,
                bold: false
            }
        }
    };


    var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
    chart.draw(data, options);
}

function drawChart2(keepers, pet_care) {
    var data = google.visualization.arrayToDataTable([
        ['Money', 'Ammount'],
        ['Keepers', keepers],
        ['Pet Care', pet_care]
    ]);

    var options = {
        title: 'Money Share',
        backgroundColor: '#F3F3F3',
        slices: {
            0: {color: '70566D'},
            1: {color: 'D6D6F4'}
        },
        titleTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 30,
            bold: false
        },
        pieSliceTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 26,
            bold: false
        },
        legend: {
            textStyle: {
                color: '0C0F0A',
                fontName: 'jomhuria',
                fontSize: 28,
                bold: false
            }
        }
    };


    var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
    chart.draw(data, options);
}

function drawChart3(keepers, owners) {
    var data = google.visualization.arrayToDataTable([
        ['User Type', 'Ammount'],
        ['Keepers', keepers],
        ['Owners', owners]
    ]);

    var options = {
        title: 'User Type Share',
        backgroundColor: '#F3F3F3',
        slices: {
            0: {color: '70566D'},
            1: {color: 'D6D6F4'}
        },
        titleTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 30,
            bold: false
        },
        pieSliceTextStyle: {
            color: '#0C0F0A',
            fontName: 'jomhuria',
            fontSize: 26,
            bold: false
        },
        legend: {
            textStyle: {
                color: '0C0F0A',
                fontName: 'jomhuria',
                fontSize: 28,
                bold: false
            }
        }
    };


    var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
    chart.draw(data, options);
}