document.addEventListener("DOMContentLoaded", function () {
    isLoggedIn();
});

function isLoggedIn() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user already logged in");
            window.location.href = "/PROJECT_359/" + xhr.response + "_home.html";
        } else if (xhr.status === 403) {
            alert(xhr.status + ": user not logged in");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    xhr.open('GET', 'GetUserSession');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send();
}


