// Illegal Phrases
var cat = "cat"
var dog = "dog"
var gata = "gata"
var skulos = "skulos"

function check_illegal_phrases(pass) {
    let len = pass.value.length;

    for (let i = 0; i < len; i++) {
        let temp = pass.value.charAt(i);
        let phrase = temp;
        for (let j = i + 1; j < len; j++) {
            phrase = phrase.concat(pass.value.charAt(j));
            if (phrase.localeCompare(cat, undefined, {sensitivity: 'base'}) === 0 || phrase.localeCompare(dog, undefined, {sensitivity: 'base'}) === 0
                    || phrase.localeCompare(gata, undefined, {sensitivity: 'base'}) === 0 || phrase.localeCompare(skulos, undefined, {sensitivity: 'base'}) === 0) {
                return true;
            }
        }
    }
    return false;
}

function bad_digits_percentage(pass) {
    let digit_count = 0;
    let char_count = 0;

    for (let i = 0; i < pass.value.length; i++) {
        c = pass.value.charAt(i);
        if (c >= '0' && c <= '9') {
            digit_count = digit_count + 1;
        } else {
            char_count = char_count + 1;
        }
    }

    let perc = digit_count / char_count;

    if (perc >= 1) {
        return true;
    } else {
        return false;
    }
}

function has_char(c) {
    return /[a-z]/.test(c);
}

function has_cap(c) {
    return /[A-Z]/.test(c);
}

function has_num(c) {
    return /[0-9]/.test(c);
}

function has_symbol(c) {
    return /[!@#\$%\^&\*\_=\+\-]/.test(c);
}

function check_strong(pass) {
    let c = pass.value;
    if (has_cap(c) && has_char(c) && has_num(c) && has_symbol(c)) {
        return true;
    } else {
        return false;
    }
}

//Checks if the password is not empty and more than 8 characters
function is_long_enough(pass) {
    let c = pass.value;
    if (c.length >= 8) {
        return true;
    } else {
        return false;
    }
}

// Variable that dictates wheather the password is good for submission
var match;
function password_check() {

    let pass = document.getElementById("password");
    let rpass = document.getElementById("rpassword");
    match = true;

    let pass_dont_match = document.getElementsByClassName("pass_dont_match_class");
    let pass_feedback_text = document.getElementById("pass_feedback");
    let pass_feedback_style = document.getElementsByClassName("pass_feedback_class");

    if (pass.value !== rpass.value) {
        document.getElementById("password").style.borderColor = "#ff0000";
        document.getElementById("rpassword").style.borderColor = "#ff0000";
        pass_dont_match[0].style.visibility = "visible";
        pass_dont_match[1].style.visibility = "visible";
        match = false;
    } else {
        document.getElementById("password").style.borderColor = "#0C0F0A";
        document.getElementById("rpassword").style.borderColor = "#0C0F0A";
        pass_dont_match[0].style.visibility = "hidden";
        pass_dont_match[1].style.visibility = "hidden";
    }

    if (bad_digits_percentage(pass) || !is_long_enough(pass)) {
        pass_feedback_text.innerHTML = "Password too weak!";
        pass_feedback_style[0].style.visibility = "visible";
        pass_feedback_style[1].style.visibility = "visible";
        match = false;
    }

    if (check_strong(pass) && is_long_enough(pass) && !bad_digits_percentage(pass)) {
        pass_feedback_text.innerHTML = "Strong Password!";
        pass_feedback_style[0].style.visibility = "visible";
        pass_feedback_style[1].style.visibility = "visible";
        match = true;
    }

    if (!bad_digits_percentage(pass) && !check_strong(pass) && is_long_enough(pass)) {
        pass_feedback_text.innerHTML = "Medium Password";
        pass_feedback_style[0].style.visibility = "visible";
        pass_feedback_style[1].style.visibility = "visible";
        match = false;
    }

    if (check_illegal_phrases(pass)) {
        pass_feedback_text.innerHTML = "Do not include: cat, dog, gata, skulos!";
        pass_feedback_style[0].style.visibility = "visible";
        pass_feedback_style[1].style.visibility = "visible";
        match = false;
    }
}

function stop_animation() {
    let pass_feedback_style = document.getElementsByClassName("pass_feedback_class");
    pass_feedback_style[0].style.animation = "fade 2s linear";
    pass_feedback_style[1].style.animation = "fade 2s linear";

    let pass_dont_match_style = document.getElementsByClassName("pass_dont_match_class");
    pass_dont_match_style[0].style.animation = "fade 2s linear";
    pass_dont_match_style[1].style.animation = "fade 2s linear";
}

function alert_password() {
    document.getElementById("password").scrollIntoView();
    let pass_feedback_style = document.getElementsByClassName("pass_feedback_class");
    pass_feedback_style[0].style.animation = "fade 2s infinite";
    pass_feedback_style[1].style.animation = "fade 2s infinite";
    setTimeout(stop_animation, 3000);

    let pass_dont_match_style = document.getElementsByClassName("pass_dont_match_class");
    pass_dont_match_style[0].style.animation = "fade 2s infinite";
    pass_dont_match_style[1].style.animation = "fade 2s infinite";
    setTimeout(stop_animation, 3000);
}

// Also checks for address and alerts if invalid
function validate_submit() {
    let form = document.getElementById("form");

    let valid = can_submit && match;

    if (valid) {
        return true;
    } else {
        if (!match) {
            alert_password();
        }
        if (!can_submit) {
            alert_address();
        }
        return false;
    }
}

window.addEventListener('keyup', () => password_check());


