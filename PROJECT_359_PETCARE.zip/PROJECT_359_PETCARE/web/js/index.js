function LogIn() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert(xhr.status + ": user logged in");
            window.location.href = "/PROJECT_359/" + xhr.response + "_home.html";
        } else if (xhr.status === 404) {
            alert(xhr.status + ": user not found");
        } else {
            alert(xhr.status + ": unknown error");
        }
    };
    var data = $('#form').serialize();
    xhr.open('POST', 'LogIn');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(data);
}


