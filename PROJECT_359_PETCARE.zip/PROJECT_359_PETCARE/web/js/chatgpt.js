function callGPT() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = xhr.response;
            } else if (xhr.status === 403) {
                document.getElementById("response_container").innerHTML = "Invalid Query";
            } else {
                document.getElementById("response_container").innerHTML = "GPT Refused";
            }
        }
    };

    var data = $("#gpt_form").serialize();
    xhr.open("GET", "AskGPT?" + data);
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();
}