document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("form").addEventListener('submit', function(event){
    event.preventDefault();
    validate_submit();
    registerUser();
});
});


