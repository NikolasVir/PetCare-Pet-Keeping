function getKeepers() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = makeKeeperTable(JSON.parse(xhr.response));
            } else if (xhr.status === 403) {
                document.getElementById("response_container").innerHTML = "Invalid Query";
            } else {
                document.getElementById("response_container").innerHTML = "No results";
            }
        }
    };

    var data = $("#gpt_form").serialize();
    xhr.open("GET", "SearchPetKeepers?" + data);
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();
}

function makeKeeperTable(petKeepers) {
    var table = '<table style="font-size: 25px; border: 1px solid black; border-collapse: collapse;">';

    var headers = ['Username', 'Email', 'Password', 'First Name', 'Last Name', 'Birthdate', 'Gender', 'Job', 'Country', 'City', 'Address', 'Latitude', 'Longitude', 'Telephone', 'Personal Page', 'Property', 'Property Description', 'Cat Keeper', 'Dog Keeper', 'Cat Price', 'Dog Price'];
    table += '<thead><tr>';

    // Filter headers to exclude sensitive information
    var filteredHeaders = headers.filter(function (header) {
        return !['Password', 'Latitude', 'Longitude', 'Address'].includes(header);
    });

    filteredHeaders.forEach(function (header) {
        table += '<th>' + header + '</th>';
    });
    table += '</tr></thead>';

    table += '<tbody>';
    petKeepers.forEach(function (petKeeper) {
        table += '<tr>';
        filteredHeaders.forEach(function (header) {
            table += '<td>' + petKeeper[header.toLowerCase().replace(/ /g, '')] + '</td>';
        });
        table += '</tr>';
    });
    table += '</tbody></table>';

    return table;
}

