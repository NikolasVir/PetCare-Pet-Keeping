document.addEventListener("DOMContentLoaded", function () {
    getAppropriateKeepers();
});

function bookKeeper() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.status + ": booking added successfuly");
            } else if (xhr.status === 404) {
                alert(xhr.status + ": keeper does not exist");
            } else if (xhr.status === 406) {
                alert(xhr.status + ": overlaps with other Booking");
            } else if (xhr.status !== 200) {
                alert(xhr.status + ": unknown error");
            }
        }
    };
    var data = $("#keeper_form").serialize();
    xhr.open('POST', 'BookKeeper');
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(data);
}

function getAppropriateKeepers() {
    var xhr = new XMLHttpRequest;
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("response_container").innerHTML = makeKeeperTable(JSON.parse(xhr.response));
            } else if (xhr.status === 404) {
                document.getElementById("response_container").innerHTML = "No results";
            } else {
                document.getElementById("response_container").innerHTML = "Unknown error: " + xhr.status;
            }
        }
    };

    xhr.open("GET", "GetAppropriateKeepers");
    xhr.setRequestHeader("Content-type", "text/plain");
    xhr.send();
}

function makeKeeperTable(petKeepers) {
    var table = '<table style="font-size: 25px; border: 1px solid black; border-collapse: collapse;">';

    var headers = ['Username', 'Email', 'Password', 'First Name', 'Last Name', 'Birthdate', 'Gender', 'Job', 'Country', 'City', 'Address', 'Latitude', 'Longitude', 'Telephone', 'Personal Page', 'Property', 'Property Description', 'Cat Keeper', 'Dog Keeper', 'Cat Price', 'Dog Price'];
    table += '<thead><tr>';

    // Filter headers to exclude sensitive information
    var filteredHeaders = headers.filter(function (header) {
        return !['Password', 'Latitude', 'Longitude', 'Address'].includes(header);
    });

    filteredHeaders.forEach(function (header) {
        table += '<th>' + header + '</th>';
    });
    table += '</tr></thead>';

    table += '<tbody>';
    petKeepers.forEach(function (petKeeper) {
        table += '<tr>';
        filteredHeaders.forEach(function (header) {
            table += '<td>' + petKeeper[header.toLowerCase().replace(/ /g, '')] + '</td>';
        });
        table += '</tr>';
    });
    table += '</tbody></table>';

    return table;
}